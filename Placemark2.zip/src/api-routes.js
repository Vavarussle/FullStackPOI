import { userApi } from "./api/user-api.js";
import { playlistApi } from "./api/playlist-api.js";
import { trackApi } from "./api/track-api.js";

export const apiRoutes = [
  { method: "GET", path: "/api/users", config: userApi.find },
  { method: "POST", path: "/api/users", config: userApi.create },
  { method: "DELETE", path: "/api/users", config: userApi.deleteAll },
  { method: "GET", path: "/api/users/{id}", config: userApi.findOne },
  { method: "POST", path: "/api/users/authenticate", config: userApi.authenticate },
  { method: "DELETE", path: "/api/users/{id}", config: userApi.deleteOne },

  { method: "POST", path: "/api/categories", config: playlistApi.create },
  { method: "DELETE", path: "/api/categories", config: playlistApi.deleteAll },
  { method: "GET", path: "/api/categories", config: playlistApi.find },
  { method: "GET", path: "/api/categories/{id}", config: playlistApi.findOne },
  { method: "DELETE", path: "/api/categories/{id}", config: playlistApi.deleteOne },

  { method: "GET", path: "/api/placemarks", config: trackApi.find },
  { method: "GET", path: "/api/placemarks/{id}", config: trackApi.findOne },
  { method: "POST", path: "/api/categories/{id}/placemarks", config: trackApi.create },
  { method: "PUT", path: "/api/placemarks/{id}", config: trackApi.update },
  { method: "DELETE", path: "/api/placemarks", config: trackApi.deleteAll },
  { method: "DELETE", path: "/api/placemarks/{id}", config: trackApi.deleteOne },
];