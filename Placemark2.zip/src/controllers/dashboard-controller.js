import { PlaylistSpec } from "../models/joi-schemas.js";
import { db } from "../models/db.js";

export const dashboardController = {
  index: {
    handler: async function (request, h) {
      const loggedInUser = request.auth.credentials;
      const categories = await db.playlistStore.getUserPlaylists(loggedInUser._id);

      const viewData = {
        title: "Placemark Dashboard",
        user: loggedInUser,
        playlists: categories,
      };
      return h.view("dashboard-view", viewData);
    },
  },

  addCategory: {
    validate: {
      payload: PlaylistSpec,
      options: { abortEarly: false },
      failAction: async function (request, h, error) {
        const loggedInUser = request.auth.credentials;
        const categories = await db.playlistStore.getUserPlaylists(loggedInUser._id);

        return h
          .view("dashboard-view", {
            title: "Add Category Error",
            user: loggedInUser,
            playlists: categories,
            errors: error.details,
          })
          .takeover()
          .code(400);
      },
    },

    handler: async function (request, h) {
      const loggedInUser = request.auth.credentials;

      const newCategory = {
        userid: loggedInUser._id,
        title: request.payload.title,
      };

      await db.playlistStore.addPlaylist(newCategory);
      return h.redirect("/dashboard");
    },
  },

  deleteCategory: {
    handler: async function (request, h) {
      const category = await db.playlistStore.getPlaylistById(request.params.id);

      if (category && category.tracks) {
        await Promise.all(category.tracks.map((placemark) => db.trackStore.deleteTrack(placemark._id)));
      }

      await db.playlistStore.deletePlaylistById(request.params.id);
      return h.redirect("/dashboard");
    },
  },
};