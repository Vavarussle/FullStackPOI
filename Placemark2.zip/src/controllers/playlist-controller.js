import { TrackSpec } from "../models/joi-schemas.js";
import { db } from "../models/db.js";
import { imageStore } from "../models/image-store.js";

export const playlistController = {
  index: {
    handler: async function (request, h) {
      const playlist = await db.playlistStore.getPlaylistById(request.params.id);
      const viewData = {
        title: "Category",
        user: request.auth.credentials,
        playlist: playlist,
      };
      return h.view("playlist-view", viewData);
    },
  },

  addPlacemark: {
    validate: {
      payload: TrackSpec,
      options: { abortEarly: false },
      failAction: async function (request, h, error) {
        const playlist = await db.playlistStore.getPlaylistById(request.params.id);
        return h
          .view("playlist-view", {
            title: "Add Placemark Error",
            user: request.auth.credentials,
            playlist: playlist,
            errors: error.details,
          })
          .takeover()
          .code(400);
      },
    },

    handler: async function (request, h) {
      const playlist = await db.playlistStore.getPlaylistById(request.params.id);

      let imageUrl = "";
      try {
        const file = request.payload.imagefile;
        if (file && file.hapi) {
          imageUrl = await imageStore.uploadImage(file);
        }
      } catch (err) {
        console.log(err);
      }

      const newTrack = {
        title: request.payload.title,
        description: request.payload.description,
        latitude: Number(request.payload.latitude),
        longitude: Number(request.payload.longitude),
        img: imageUrl,
      };

      await db.trackStore.addTrack(playlist._id, newTrack);
      return h.redirect(`/playlist/${playlist._id}`);
    },

    payload: {
      multipart: true,
      output: "data",
      maxBytes: 209715200,
      parse: true,
    },
  },

  deletePlacemark: {
    handler: async function (request, h) {
      const playlist = await db.playlistStore.getPlaylistById(request.params.id);
      await db.trackStore.deleteTrack(request.params.trackid);
      return h.redirect(`/playlist/${playlist._id}`);
    },
  },

  uploadImage: {
    handler: async function (request, h) {
      try {
        const playlist = await db.playlistStore.getPlaylistById(request.params.id);
        const file = request.payload.imagefile;
        if (file && file.hapi) {
          const url = await imageStore.uploadImage(file);
          playlist.img = url;
          await db.playlistStore.updatePlaylist(playlist);
        }
        return h.redirect(`/playlist/${playlist._id}`);
      } catch (err) {
        console.log(err);
        return h.redirect(`/playlist/${request.params.id}`);
      }
    },
    payload: {
      multipart: true,
      output: "data",
      maxBytes: 209715200,
      parse: true,
    },
  },
};