import { TrackSpec } from "../models/joi-schemas.js";
import { db } from "../models/db.js";
import { imageStore } from "../models/image-store.js";

export const trackController = {
  index: {
    handler: async function (request, h) {
      const category = await db.playlistStore.getPlaylistById(request.params.id);
      const placemark = await db.trackStore.getTrackById(request.params.placemarkid);

      const viewData = {
        title: "Edit Placemark",
        user: request.auth.credentials,
        playlist: category,
        track: placemark,
      };

      return h.view("track-view", viewData);
    },
  },

  update: {
    validate: {
      payload: TrackSpec,
      options: { abortEarly: false },
      failAction: async function (request, h, error) {
        const category = await db.playlistStore.getPlaylistById(request.params.id);
        const placemark = await db.trackStore.getTrackById(request.params.placemarkid);

        return h
          .view("track-view", {
            title: "Edit Placemark Error",
            user: request.auth.credentials,
            playlist: category,
            track: placemark,
            errors: error.details,
          })
          .takeover()
          .code(400);
      },
    },

    handler: async function (request, h) {
      const placemark = await db.trackStore.getTrackById(request.params.placemarkid);

      const updatedPlacemark = {
        title: request.payload.title,
        description: request.payload.description,
        latitude: Number(request.payload.latitude),
        longitude: Number(request.payload.longitude),
        img: placemark.img || "",
      };

      await db.trackStore.updateTrack(placemark, updatedPlacemark);
      return h.redirect(`/category/${request.params.id}`);
    },
  },

  uploadImage: {
    handler: async function (request, h) {
      const placemark = await db.trackStore.getTrackById(request.params.placemarkid);

      try {
        const file = request.payload.imagefile;
        if (file && file.hapi) {
          const url = await imageStore.uploadImage(file);

          const updatedPlacemark = {
            title: placemark.title,
            description: placemark.description,
            latitude: placemark.latitude,
            longitude: placemark.longitude,
            img: url,
          };

          await db.trackStore.updateTrack(placemark, updatedPlacemark);
        }
      } catch (err) {
        console.log(err);
      }

      return h.redirect(`/placemark/${request.params.id}/edit/${request.params.placemarkid}`);
    },

    payload: {
      multipart: true,
      output: "data",
      maxBytes: 209715200,
      parse: true,
    },
  },
};