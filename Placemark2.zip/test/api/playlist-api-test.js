import { assert } from "chai";
import { placemarkService } from "./placemark-service.js";
import { maggie, maggieCredentials, mozart, testPlaylists } from "../fixtures.js";
import { assertSubset } from "../test-utils.js";

suite("Category API tests", () => {
  let user = null;

  setup(async () => {
    placemarkService.clearAuth();
    await placemarkService.deleteAllCategories();
    await placemarkService.deleteAllUsers();
    user = await placemarkService.createUser(maggie);
    await placemarkService.authenticate(maggieCredentials);
    mozart.userid = user._id;
  });

  test("create category", async () => {
    const returnedCategory = await placemarkService.createCategory(mozart);
    assertSubset(mozart, returnedCategory);
    assert.isDefined(returnedCategory._id);
  });

  test("delete a category", async () => {
    const category = await placemarkService.createCategory(mozart);
    const response = await placemarkService.deleteCategory(category._id);
    assert.equal(response, "");
    const returnedCategories = await placemarkService.getAllCategories();
    assert.equal(returnedCategories.length, 0);
  });

  test("create multiple categories", async () => {
    for (let i = 0; i < testPlaylists.length; i += 1) {
      testPlaylists[i].userid = user._id;
      // eslint-disable-next-line no-await-in-loop
      await placemarkService.createCategory(testPlaylists[i]);
    }
    const returnedCategories = await placemarkService.getAllCategories();
    assert.equal(returnedCategories.length, testPlaylists.length);
    for (let i = 0; i < returnedCategories.length; i += 1) {
      assertSubset(testPlaylists[i], returnedCategories[i]);
    }
  });

  test("delete all categories", async () => {
    for (let i = 0; i < testPlaylists.length; i += 1) {
      testPlaylists[i].userid = user._id;
      // eslint-disable-next-line no-await-in-loop
      await placemarkService.createCategory(testPlaylists[i]);
    }
    let returnedCategories = await placemarkService.getAllCategories();
    assert.equal(returnedCategories.length, testPlaylists.length);
    await placemarkService.deleteAllCategories();
    returnedCategories = await placemarkService.getAllCategories();
    assert.equal(returnedCategories.length, 0);
  });

  test("get a category", async () => {
    const category = await placemarkService.createCategory(mozart);
    const returnedCategory = await placemarkService.getCategory(category._id);
    assert.deepEqual(category, returnedCategory);
  });

  test("get a category - bad id", async () => {
    try {
      await placemarkService.getCategory("1234");
      assert.fail("Should not return a category");
    } catch (error) {
      assert.equal(error.response.data.message, "No Category with this id");
      assert.equal(error.response.data.statusCode, 503);
    }
  });

  test("get a category - deleted category", async () => {
    const category = await placemarkService.createCategory(mozart);
    await placemarkService.deleteCategory(category._id);
    try {
      await placemarkService.getCategory(category._id);
      assert.fail("Should not return a category");
    } catch (error) {
      assert.equal(error.response.data.message, "No Category with this id");
      assert.equal(error.response.data.statusCode, 404);
    }
  });
});