import { assert } from "chai";
import { placemarkService } from "./placemark-service.js";
import { assertSubset } from "../test-utils.js";
import { maggie, maggieCredentials, mozart, concerto, testTracks } from "../fixtures.js";

suite("Placemark API tests", () => {
  let user = null;
  let category = null;

  setup(async () => {
    placemarkService.clearAuth();
    await placemarkService.deleteAllPlacemarks();
    await placemarkService.deleteAllCategories();
    await placemarkService.deleteAllUsers();

    user = await placemarkService.createUser(maggie);
    await placemarkService.authenticate(maggieCredentials);

    mozart.userid = user._id;
    category = await placemarkService.createCategory(mozart);
  });

  test("create placemark", async () => {
    const returnedPlacemark = await placemarkService.createPlacemark(category._id, concerto);
    assertSubset(concerto, returnedPlacemark);
    assert.isDefined(returnedPlacemark._id);
  });

  test("create multiple placemarks", async () => {
    for (let i = 0; i < testTracks.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await placemarkService.createPlacemark(category._id, testTracks[i]);
    }

    const returnedPlacemarks = await placemarkService.getAllPlacemarks();
    assert.equal(returnedPlacemarks.length, testTracks.length);

    for (let i = 0; i < returnedPlacemarks.length; i += 1) {
      assertSubset(testTracks[i], returnedPlacemarks[i]);
    }
  });

  test("delete placemark", async () => {
    const placemark = await placemarkService.createPlacemark(category._id, concerto);
    const response = await placemarkService.deletePlacemark(placemark._id);
    assert.equal(response, "");
    const returnedPlacemarks = await placemarkService.getAllPlacemarks();
    assert.equal(returnedPlacemarks.length, 0);
  });

  test("get a placemark", async () => {
    const placemark = await placemarkService.createPlacemark(category._id, concerto);
    const returnedPlacemark = await placemarkService.getPlacemark(placemark._id);
    assertSubset(concerto, returnedPlacemark);
  });

  test("update a placemark", async () => {
    const placemark = await placemarkService.createPlacemark(category._id, concerto);
    const updatedPlacemark = {
      title: "Hook Lighthouse",
      description: "Historic lighthouse in Wexford",
      latitude: 52.1248,
      longitude: -6.9302,
      img: "",
    };

    const returnedPlacemark = await placemarkService.updatePlacemark(placemark._id, updatedPlacemark);
    assertSubset(updatedPlacemark, returnedPlacemark);
  });

  test("get all placemarks", async () => {
    for (let i = 0; i < testTracks.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await placemarkService.createPlacemark(category._id, testTracks[i]);
    }

    const returnedPlacemarks = await placemarkService.getAllPlacemarks();
    assert.equal(returnedPlacemarks.length, testTracks.length);
  });

  test("get placemark detail", async () => {
    const placemark = await placemarkService.createPlacemark(category._id, concerto);
    const returnedPlacemark = await placemarkService.getPlacemark(placemark._id);
    assert.deepEqual(returnedPlacemark.title, placemark.title);
    assert.deepEqual(returnedPlacemark.description, placemark.description);
    assert.deepEqual(returnedPlacemark.latitude, placemark.latitude);
    assert.deepEqual(returnedPlacemark.longitude, placemark.longitude);
  });

  test("get a placemark - bad id", async () => {
    try {
      await placemarkService.getPlacemark("1234");
      assert.fail("Should not return a placemark");
    } catch (error) {
      assert.equal(error.response.data.message, "No Placemark with this id");
      assert.equal(error.response.data.statusCode, 503);
    }
  });

  test("get a placemark - deleted placemark", async () => {
    const placemark = await placemarkService.createPlacemark(category._id, concerto);
    await placemarkService.deletePlacemark(placemark._id);
    try {
      await placemarkService.getPlacemark(placemark._id);
      assert.fail("Should not return a placemark");
    } catch (error) {
      assert.equal(error.response.data.message, "No Placemark with this id");
      assert.equal(error.response.data.statusCode, 404);
    }
  });

  test("denormalised category", async () => {
    for (let i = 0; i < testTracks.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await placemarkService.createPlacemark(category._id, testTracks[i]);
    }
    const returnedCategory = await placemarkService.getCategory(category._id);
    assert.equal(returnedCategory.tracks.length, testTracks.length);
  });
});